import CallToAction from '@/components/ui/CallToAction';
import React from 'react';

function Faqs() {
  return (
    <div>
      <CallToAction className="mt-[200px]" />
    </div>
  );
}

export default Faqs;
